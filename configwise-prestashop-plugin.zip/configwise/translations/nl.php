<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{configwise}prestashop>configwise_99326579a8a6254037caf44c85a41747'] = 'ConfigWise AR';
$_MODULE['<{configwise}prestashop>configwise_5be437d9af7e40ad9f844b76027bb058'] = 'AR Content Management voor uw e-commerce webshop. Gebruik hoogwaardige AR-content van uw producten met Augmented Reality (app en web), om de verkoop te stimuleren en de conversie te verhogen.';
$_MODULE['<{configwise}prestashop>configwise_f4f70727dc34561dfde1a3c529b6205c'] = 'Instellingen';
$_MODULE['<{configwise}prestashop>configwise_cebd5bbe0ffdecc270a8a324e5a277dd'] = 'Live-modus';
$_MODULE['<{configwise}prestashop>configwise_ea9df7a306e2f8b5af37b67084d0c984'] = 'Gebruik deze module in live-modus';
$_MODULE['<{configwise}prestashop>configwise_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Ingeschakeld';
$_MODULE['<{configwise}prestashop>configwise_b9f5c797ebbf55adccdd8539a65a0241'] = 'Uitgeschakeld';
$_MODULE['<{configwise}prestashop>configwise_97f08a40f22a625d0cbfe03db3349108'] = 'Product nummer';
$_MODULE['<{configwise}prestashop>configwise_4994a8ffeba4ac3140beb89e8d41f174'] = 'Taal';
$_MODULE['<{configwise}prestashop>configwise_3bc9cc912eff538e298085565c6baed1'] = 'Voer kanaal waarde in';
$_MODULE['<{configwise}prestashop>configwise_36b283aea4b193fc5fd1eaa76e20530f'] = 'Kanaal waarde';
$_MODULE['<{configwise}prestashop>configwise_eae639a70006feff484a39363c977e24'] = 'Domein';
$_MODULE['<{configwise}prestashop>configwise_0784f5d137f344138bc1a0dcf7319c1f'] = 'Voer bedrijfsreferentienummer in';
$_MODULE['<{configwise}prestashop>configwise_11c67d8b2b243a6676368cdb9cdfed3f'] = 'Bedrijfsreferentienummer';
$_MODULE['<{configwise}prestashop>configwise_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
